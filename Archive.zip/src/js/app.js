import 'babel-polyfill';
import 'svgxuse';
import './Common';
